# Welcome to Roblox Key System!

based on .php file ( no database needed ) also this is only 1-time key system ( HWID Added if you have private keys ), if the key is used, it wouldn't longer valid until you get new key. Unless you can utilize this Key System to 24 Hours Key System on ( .NET / C# ). Yes could possible on C++ but i don't have that code lol

[![Build Status](https://travis-ci.org/joemccann/dillinger.svg?branch=master)](https://travis-ci.org/joemccann/dillinger)


## Features ( Added as of 2/3/2022 )

- Added HWID for your Premium stuff 
- Prevent your Key System being Bypassable Easily.. 
- Can 24 Hours by though utilization of your Client Side aka C# Source. lol
- I'm not a Robot Captcha 
- 

C# Source Code:

```sh
https://github.com/Panda-Respiratory/Roblox-Key-System/tree/main/C%23%20Source%20Code
```

What you need:

> 1.] Your Braincells ( need it badly )
> 
> 2.] A Custom Domain ofc so google recaptcha will work
> 
> 3.] Google Recaptcha ( v2 )

Possible Notice
> Replace the Recaptcha's Site Key and Secret Key with your own Site Key and Secret Key or it won't worked.
> 
> Replace Some Link like ( duhh you know it already ) 
> 
> Add your own Design on it lol aka Web Design.








Edit the index.php, step2.php, step3.php, and generated.php then replace the site key & secret key with yours.

https://www.google.com/recaptcha/admin/create

Good Luck :)

## Credits

Credit to these guy who makes your Key System.

| Users | Contribution |
| ------ | ------ |
| SkieHacker | Modding & Improving the Key System |
| UsifFar | for index.php, i watch his tutorial and i learn some shits at least |


