<?
ini_set('display_errors', 'Off');
 error_reporting(0);
session_start();

if(!isset($_SESSION['time']))
{
	echo "<meta http-equiv='Refresh' Content='2;url=https://pandatechnology.xyz/KeySystem/Panda/'>"; 
	return;
}
header("Refresh: 3; URL=https://mboost.me/a/5ke");  
?>

<html>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<meta charset="utf-8">


<title>Redirecting </title>
</html>
