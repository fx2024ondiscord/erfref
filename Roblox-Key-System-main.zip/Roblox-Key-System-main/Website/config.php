<?php
return array(
    'host' => 'remotemysql.com',
    'username' => 'zvvqpzsMRN',
    'password' => 'vk1pIO1Eje',
    'database' => 'zvvqpzsMRN',
    'recaptcha' => '6LdQCd4aAAAAAGDOR2sr6y_T_ZpFcERYvVVFV2k8'
);
?>
