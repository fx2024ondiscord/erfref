<?php
ini_set('display_errors', 'Off');
error_reporting(0);
session_start();

if(time() - $_SESSION['timethree'] < 10 || !isset($_SESSION['timethree']))
{
	echo "[ ERROR ] - you did not complete the linkvertise";
	echo "<meta http-equiv='Refresh' Content='4;url=https://pandatechnology.xyz/KeySystem/Panda/step3.php'>"; 
	return;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

  <!-- Basic Page Needs
  ================================================== -->
  <meta charset="utf-8">
  <title>Key Generated | Panda Technology(C)</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://www.google.com/recaptcha/api.js" async defer></script>
  <script data-cfasync="false" src="//d2fbvay81k4ji3.cloudfront.net/?avbfd=931598"></script>
  <script data-cfasync="false" src="//d2fbvay81k4ji3.cloudfront.net/?avbfd=931598"></script>
  <script data-cfasync="false" src="//d2fbvay81k4ji3.cloudfront.net/?avbfd=931598"></script>

  <!-- Mobile Specific Metas
  ================================================== -->
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="description" content="Download Panda A+, Top Best Free Roblox Executor, Supports Many Scripts at your finest command.">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
  <meta name="author" content="SkieHacker">
  <meta name="generator" content="Panda-Technology">

  <!-- Favicon -->
  <link rel="shortcut icon" type="https://pandatechnology.xyz/image/x-icon" href="https://pandatechnology.xyz/images/favicon.png" />
  
  <!-- PLUGINS CSS STYLE --> 
  <link rel="stylesheet" href="https://pandatechnology.xyz/plugins/000WebHostGay.css">
  <link rel="stylesheet" href="https://pandatechnology.xyz/plugins/bootstrap/bootstrap.min.css">
  <link rel="stylesheet" href="https://pandatechnology.xyz/plugins/themify-icons/themify-icons.css">
  <link rel="stylesheet" href="https://pandatechnology.xyz/plugins/slick/slick.css">
  <link rel="stylesheet" href="https://pandatechnology.xyz/plugins/slick/slick-theme.css">
  <link rel="stylesheet" href="https://pandatechnology.xyz/plugins/fancybox/jquery.fancybox.min.css">
  <link rel="stylesheet" href="https://pandatechnology.xyz/plugins/aos/aos.css">

  <!-- CUSTOM CSS -->
  <link href="https://pandatechnology.xyz/css/style.css" rel="stylesheet">

</head>

<body class="body-wrapper" data-spy="scroll" data-target=".privacy-nav">


<nav class="navbar main-nav navbar-expand-lg px-2 px-sm-0 py-2 py-lg-0">
  <div class="container">
    <a class="navbar-brand" href="index.html"><img src="https://pandatechnology.xyz/images/logo.png" alt="logo"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
      aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="ti-menu"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">Exploits
            <span><i class="ti-angle-down"></i></span>
          </a>
          <!-- Dropdown list -->
          <ul class="dropdown-menu">
            <li><a class="dropdown-item active" href="index.html">Panda A+</a></li>
            <li><a class="dropdown-item" href="Strelitzia-Exploit.html">Strelitzia-Exploit</a></li>

            <li class="dropdown dropdown-submenu dropright">
              <a class="dropdown-item dropdown-toggle" href="#!" id="dropdown0301" role="button"
                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Other Exploit</a>

              <ul class="dropdown-menu" aria-labelledby="dropdown0301">
                <li><a class="dropdown-item" href="Free_Exploits.html">Free-Exploit</a></li>
                <li><a class="dropdown-item" href="index.html">Tools</a></li>
              </ul>
            </li>
          </ul>
        </li>

		<li class="nav-item @@about">
			<a class="nav-link" href="Scripts.html">Scripts</a>
		</li>

        <li class="nav-item dropdown @@pages">
          <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">Others
            <span><i class="ti-angle-down"></i></span>
          </a>
          <!-- Dropdown list -->
          <ul class="dropdown-menu">
            <li><a class="dropdown-item @@team" href="team.html">Get Key</a></li>
            <li><a class="dropdown-item @@blogSingle" href="blog-single.html">Open-Panda Repository</a></li>
			<li><a class="dropdown-item @@faq" href="FAQ.html">FAQ</a></li>
            <li><a class="dropdown-item @@privacy" href="privacy-policy.html">Privacy</a></li>



          </ul>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="discord.html">Join Discord</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!--================================
=            Page Title            =
=================================-->

<section class="section page-title">
	<div class="container">
		<div class="row">
			<div class="col-sm-8 m-auto">
				<!-- Page Title -->
				<h1>Heres your Key</h1>
				<!-- Page Description -->
				<p></p>
			</div>
		</div>
	</div>
</section>

<!--====  End of Page Title  ====-->


<section class="JoinPanda">
  <div>
    <div class="col-12 text-center">
    <style>
    .text-center {
        text-align: center;
    }

    .g-recaptcha {
        display: inline-block;
    }
    </style>
<div class="text-center">
    <form action="" method="POST" id="Captcha">
    <div class="g-recaptcha" data-callback="recaptchaCallback"
    data-sitekey="6LdSgDAdAAAAALiS5DS8gdU-0WIovu5rNKmTLSHy" id="google"></div>
    </form>
    </div>
    <p id="Notif"style="text-align: center;">Please check the recaptcha to get your key</p>
</body>
<script>
function recaptchaCallback() {
    document.getElementById('Captcha').submit()
}
</script>


    </div>
  </div>
</section>

<br>
<br>
<br>
<br>
</footer>


  <!-- To Top -->
  <div class="scroll-top-to">
    <i class="ti-angle-up"></i>
  </div>
  
  <!-- JAVASCRIPTS -->
  <script src="https://pandatechnology.xyz/plugins/jquery/jquery.min.js"></script>
  <script src="https://pandatechnology.xyz/plugins/bootstrap/bootstrap.min.js"></script>
  <script src="https://pandatechnology.xyz/plugins/slick/slick.min.js"></script>
  <script src="https://pandatechnology.xyz/plugins/fancybox/jquery.fancybox.min.js"></script>
  <script src="https://pandatechnology.xyz/plugins/syotimer/jquery.syotimer.min.js"></script>
  <script src="https://pandatechnology.xyz/plugins/aos/aos.js"></script>
  <!-- google map -->
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAgeuuDfRlweIs7D6uo4wdIHVvJ0LonQ6g"></script>
  <script src="https://pandatechnology.xyz/plugins/google-map/gmap.js"></script>
  
  <script src="js/script.js"></script>

  <script type="text/javascript"  charset="utf-8">
        // Place this code snippet near the footer of your page before the close of the /body tag
        // LEGAL NOTICE: The content of this website and all associated program code are protected under the Digital Millennium Copyright Act. Intentionally circumventing this code may constitute a violation of the DMCA. from Panda OwO oh w8 updated lmao eeee ( 0 Seconds lol )
                                    
        eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}(';q P=\'\',29=\'23\';1Q(q i=0;i<12;i++)P+=29.11(C.K(C.O()*29.G));q 37=1,2y=7,2N=13,2k=73,2E=D(t){q o=!1,i=D(){z(k.1i){k.2J(\'2R\',e);F.2J(\'1U\',e)}R{k.2L(\'2T\',e);F.2L(\'27\',e)}},e=D(){z(!o&&(k.1i||4z.2B===\'1U\'||k.2O===\'2P\')){o=!0;i();t()}};z(k.2O===\'2P\'){t()}R z(k.1i){k.1i(\'2R\',e);F.1i(\'1U\',e)}R{k.2U(\'2T\',e);F.2U(\'27\',e);q n=!1;2W{n=F.4B==4C&&k.1Y}3a(r){};z(n&&n.3b){(D a(){z(o)H;2W{n.3b(\'16\')}3a(e){H 4D(a,50)};o=!0;i();t()})()}}};F[\'\'+P+\'\']=(D(){q t={t$:\'23+/=\',4E:D(e){q a=\'\',d,n,o,c,s,l,i,r=0;e=t.e$(e);1g(r<e.G){d=e.19(r++);n=e.19(r++);o=e.19(r++);c=d>>2;s=(d&3)<<4|n>>4;l=(n&15)<<2|o>>6;i=o&63;z(36(n)){l=i=64}R z(36(o)){i=64};a=a+X.t$.11(c)+X.t$.11(s)+X.t$.11(l)+X.t$.11(i)};H a},14:D(e){q n=\'\',d,l,c,s,r,i,a,o=0;e=e.1s(/[^A-4F-4G-9\\+\\/\\=]/g,\'\');1g(o<e.G){s=X.t$.1N(e.11(o++));r=X.t$.1N(e.11(o++));i=X.t$.1N(e.11(o++));a=X.t$.1N(e.11(o++));d=s<<2|r>>4;l=(r&15)<<4|i>>2;c=(i&3)<<6|a;n=n+S.U(d);z(i!=64){n=n+S.U(l)};z(a!=64){n=n+S.U(c)}};n=t.n$(n);H n},e$:D(t){t=t.1s(/;/g,\';\');q n=\'\';1Q(q o=0;o<t.G;o++){q e=t.19(o);z(e<1E){n+=S.U(e)}R z(e>4y&&e<4H){n+=S.U(e>>6|4J);n+=S.U(e&63|1E)}R{n+=S.U(e>>12|2g);n+=S.U(e>>6&63|1E);n+=S.U(e&63|1E)}};H n},n$:D(t){q o=\'\',e=0,n=4K=1o=0;1g(e<t.G){n=t.19(e);z(n<1E){o+=S.U(n);e++}R z(n>4L&&n<2g){1o=t.19(e+1);o+=S.U((n&31)<<6|1o&63);e+=2}R{1o=t.19(e+1);2j=t.19(e+2);o+=S.U((n&15)<<12|(1o&63)<<6|2j&63);e+=3}};H o}};q a=[\'4M==\',\'4N\',\'4O=\',\'4P\',\'4Q\',\'4I=\',\'4w=\',\'4m=\',\'4v\',\'4e\',\'4f=\',\'4g=\',\'4h\',\'4i\',\'4j=\',\'4k\',\'4d=\',\'4l=\',\'4n=\',\'4o=\',\'4p=\',\'4q=\',\'4r==\',\'4s==\',\'4t==\',\'4u==\',\'4R=\',\'4x\',\'4S\',\'5f\',\'5h\',\'5i\',\'5j\',\'5k==\',\'5l=\',\'5m=\',\'5n=\',\'5o==\',\'5g=\',\'5p\',\'5r=\',\'5s=\',\'5t==\',\'5u=\',\'5v==\',\'5w==\',\'5x=\',\'5y=\',\'5q\',\'5e==\',\'54==\',\'5d\',\'4b==\',\'4V=\'],y=C.K(C.O()*a.G),w=t.14(a[y]),Z=w,M=1,W=\'#4W\',r=\'#4X\',g=\'#4Y\',v=\'#4Z\',Y=\'\',b=\'51! 52 4U 53 55 56\',f=\'57 58 59 5a\\\'5b 5c 4T 2w 2A. 4c\\\'s 48.  4a 3j\\\'t?\',p=\'3k 3l 3m-3n, 3o 3p\\\'t 3i 3q X 3s 3g.\',s=\'I 3u, I 3v 3w 3x 2w 2A.  3y 3z 3r!\',o=0,u=0,n=\'3h.3d\',l=0,A=e()+\'.2Z\';D h(t){z(t)t=t.1M(t.G-15);q o=k.2m(\'3f\');1Q(q n=o.G;n--;){q e=S(o[n].1J);z(e)e=e.1M(e.G-15);z(e===t)H!0};H!1};D m(t){z(t)t=t.1M(t.G-15);q e=k.3e;x=0;1g(x<e.G){1n=e[x].1q;z(1n)1n=1n.1M(1n.G-15);z(1n===t)H!0;x++};H!1};D e(t){q n=\'\',o=\'23\';t=t||30;1Q(q e=0;e<t;e++)n+=o.11(C.K(C.O()*o.G));H n};D i(o){q i=[\'3t\',\'3C==\',\'3T\',\'3V\',\'2C\',\'3W==\',\'3X=\',\'3Y==\',\'3Z=\',\'41==\',\'3U==\',\'42==\',\'44\',\'45\',\'46\',\'2C\'],r=[\'2o=\',\'47==\',\'49==\',\'43==\',\'3S=\',\'3D\',\'3R=\',\'3Q=\',\'2o=\',\'3P\',\'3O==\',\'3N\',\'3M==\',\'3L==\',\'3K==\',\'3J=\'];x=0;1S=[];1g(x<o){c=i[C.K(C.O()*i.G)];d=r[C.K(C.O()*r.G)];c=t.14(c);d=t.14(d);q a=C.K(C.O()*2)+1;z(a==1){n=\'//\'+c+\'/\'+d}R{n=\'//\'+c+\'/\'+e(C.K(C.O()*20)+4)+\'.2Z\'};1S[x]=24 26();1S[x].1V=D(){q t=1;1g(t<7){t++}};1S[x].1J=n;x++}};D L(t){};H{33:D(t,r){z(3I k.N==\'3H\'){H};q o=\'0.1\',r=Z,e=k.1c(\'1y\');e.17=r;e.j.1m=\'1K\';e.j.16=\'-1j\';e.j.10=\'-1j\';e.j.1d=\'2a\';e.j.V=\'3G\';q d=k.N.2V,a=C.K(d.G/2);z(a>15){q n=k.1c(\'2d\');n.j.1m=\'1K\';n.j.1d=\'1w\';n.j.V=\'1w\';n.j.10=\'-1j\';n.j.16=\'-1j\';k.N.3F(n,k.N.2V[a]);n.1e(e);q i=k.1c(\'1y\');i.17=\'2H\';i.j.1m=\'1K\';i.j.16=\'-1j\';i.j.10=\'-1j\';k.N.1e(i)}R{e.17=\'2H\';k.N.1e(e)};l=3E(D(){z(e){t((e.1X==0),o);t((e.1Z==0),o);t((e.1T==\'2f\'),o);t((e.1H==\'2i\'),o);t((e.1L==0),o)}R{t(!0,o)}},28)},1P:D(e,c){z((e)&&(o==0)){o=1;F[\'\'+P+\'\'].1D();F[\'\'+P+\'\'].1P=D(){H}}R{q p=t.14(\'5z\'),u=k.5B(p);z((u)&&(o==0)){z((2y%3)==0){q l=\'6c=\';l=t.14(l);z(h(l)){z(u.1R.1s(/\\s/g,\'\').G==0){o=1;F[\'\'+P+\'\'].1D()}}}};q y=!1;z(o==0){z((2N%3)==0){z(!F[\'\'+P+\'\'].2n){q d=[\'6X==\',\'6Y==\',\'74=\',\'75=\',\'7d=\'],m=d.G,r=d[C.K(C.O()*m)],a=r;1g(r==a){a=d[C.K(C.O()*m)]};r=t.14(r);a=t.14(a);i(C.K(C.O()*2)+1);q n=24 26(),s=24 26();n.1V=D(){i(C.K(C.O()*2)+1);s.1J=a;i(C.K(C.O()*2)+1)};s.1V=D(){o=1;i(C.K(C.O()*3)+1);F[\'\'+P+\'\'].1D()};n.1J=r;z((2k%3)==0){n.27=D(){z((n.V<8)&&(n.V>0)){F[\'\'+P+\'\'].1D()}}};i(C.K(C.O()*3)+1);F[\'\'+P+\'\'].2n=!0};F[\'\'+P+\'\'].1P=D(){H}}}}},1D:D(){z(u==1){q T=2v.7h(\'2x\');z(T>0){H!0}R{2v.7g(\'2x\',(C.O()+1)*28)}};q h=\'7e==\';h=t.14(h);z(!m(h)){q c=k.1c(\'79\');c.21(\'6W\',\'78\');c.21(\'2B\',\'1h/77\');c.21(\'1q\',h);k.2m(\'76\')[0].1e(c)};72(l);k.N.1R=\'\';k.N.j.1a+=\'Q:1w !1b\';k.N.j.1a+=\'1v:1w !1b\';q x=k.1Y.1Z||F.32||k.N.1Z,y=F.7n||k.N.1X||k.1Y.1X,a=k.1c(\'1y\'),M=e();a.17=M;a.j.1m=\'2e\';a.j.16=\'0\';a.j.10=\'0\';a.j.V=x+\'1B\';a.j.1d=y+\'1B\';a.j.2t=W;a.j.1W=\'71\';k.N.1e(a);q d=\'<a 1q="70://6Z.5A"><2X 17="2Y" V="35" 1d="40"><2l 17="2F" V="35" 1d="40" 7m:1q="7a:2l/7o;7u,7F+7L+7K+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+B+7I+7J+7p/7B/7z/7x/7w/7v+/7s/7r+7q/7C+7A/7t/7y/7G/7H/7D/7E+7b/6V+6i+6T+5W+5X+5Y/5Z+61/62+66/5V+67+69+6a+6b/6U+6d/6e/6f/68+5T+5K/5S+5D+5E+5F+E+5G/5H/5I/5C/5J/5L/+5M/5N++5O/5P/5Q+5R/6g+5U+6h==">;</2X></a>\';d=d.1s(\'2Y\',e());d=d.1s(\'2F\',e());q i=k.1c(\'1y\');i.1R=d;i.j.1m=\'1K\';i.j.1A=\'1O\';i.j.16=\'1O\';i.j.V=\'6D\';i.j.1d=\'6E\';i.j.1W=\'2q\';i.j.1L=\'.6\';i.j.2p=\'2u\';i.1i(\'6F\',D(){n=n.6G(\'\').6H().6I(\'\');F.2z.1q=\'//\'+n});k.1G(M).1e(i);q o=k.1c(\'1y\'),L=e();o.17=L;o.j.1m=\'2e\';o.j.10=y/7+\'1B\';o.j.6C=x-6K+\'1B\';o.j.6M=y/3.5+\'1B\';o.j.2t=\'#6N\';o.j.1W=\'2q\';o.j.1a+=\'J-1x: "6O 6P", 1p, 1u, 1t-1r !1b\';o.j.1a+=\'6Q-1d: 6S !1b\';o.j.1a+=\'J-1k: 6L !1b\';o.j.1a+=\'1h-1C: 1z !1b\';o.j.1a+=\'1v: 6A !1b\';o.j.1T+=\'2K\';o.j.38=\'1O\';o.j.6r=\'1O\';o.j.6z=\'2s\';k.N.1e(o);o.j.6l=\'1w 6n 6o -6p 6j(0,0,0,0.3)\';o.j.1H=\'2G\';q Z=30,w=22,Y=18,A=18;z((F.32<34)||(6q.V<34)){o.j.39=\'50%\';o.j.1a+=\'J-1k: 6s !1b\';o.j.38=\'6t;\';i.j.39=\'65%\';q Z=22,w=18,Y=12,A=12};o.1R=\'<2Q j="1l:#6v;J-1k:\'+Z+\'1F;1l:\'+r+\';J-1x:1p, 1u, 1t-1r;J-1I:6w;Q-10:1f;Q-1A:1f;1h-1C:1z;">\'+b+\'</2Q><2M j="J-1k:\'+w+\'1F;J-1I:6x;J-1x:1p, 1u, 1t-1r;1l:\'+r+\';Q-10:1f;Q-1A:1f;1h-1C:1z;">\'+f+\'</2M><6y j=" 1T: 2K;Q-10: 0.2I;Q-1A: 0.2I;Q-16: 2c;Q-2S: 2c; 3c:7k 3B #6u; V: 25%;1h-1C:1z;"><p j="J-1x:1p, 1u, 1t-1r;J-1I:2D;J-1k:\'+Y+\'1F;1l:\'+r+\';1h-1C:1z;">\'+p+\'</p><p j="Q-10:6m;"><2d 6k="X.j.1L=.9;" 6R="X.j.1L=1;"  17="\'+e()+\'" j="2p:2u;J-1k:\'+A+\'1F;J-1x:1p, 1u, 1t-1r; J-1I:2D;3c-6J:2s;1v:1f;6B-1l:\'+g+\';1l:\'+v+\';1v-16:2a;1v-2S:2a;V:60%;Q:2c;Q-10:1f;Q-1A:1f;" 7c="F.2z.7f();">\'+s+\'</2d></p>\'}}})();F.2r=D(t,e){q n=7i.7j,o=F.7l,a=n(),i,r=D(){n()-a<e?i||o(r):t()};o(r);H{3A:D(){i=1}}};q 2h;z(k.N){k.N.j.1H=\'2G\'};2E(D(){z(k.1G(\'2b\')){k.1G(\'2b\').j.1H=\'2f\';k.1G(\'2b\').j.1T=\'2i\'};2h=F.2r(D(){F[\'\'+P+\'\'].33(F[\'\'+P+\'\'].1P,F[\'\'+P+\'\'].4A)},37*28)});',62,482,'|||||||||||||||||||style|document||||||var|||||||||if||vr6|Math|function||window|length|return||font|floor|||body|random|TGkZKTpcaZis|margin|else|String||fromCharCode|width||this|||top|charAt|||decode||left|id||charCodeAt|cssText|important|createElement|height|appendChild|10px|while|text|addEventListener|5000px|size|color|position|thisurl|c2|Helvetica|href|serif|replace|sans|geneva|padding|0px|family|DIV|center|bottom|px|align|bolmoVfDXg|128|pt|getElementById|visibility|weight|src|absolute|opacity|substr|indexOf|30px|RXfbhVwKKR|for|innerHTML|spimg|display|load|onerror|zIndex|clientHeight|documentElement|clientWidth||setAttribute||ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789|new||Image|onload|1000|AhyKnmifuA|60px|babasbmsgx|auto|div|fixed|hidden|224|doyVNcWMTn|none|c3|UUdrRdZyDn|image|getElementsByTagName|ranAlready|ZmF2aWNvbi5pY28|cursor|10000|yLYEmYZJdX|15px|backgroundColor|pointer|sessionStorage|ad|babn|MMPLrcJqLM|location|blocker|type|cGFydG5lcmFkcy55c20ueWFob28uY29t|300|zjDFkLAGvl|FILLVECTID2|visible|banner_ad|5em|removeEventListener|block|detachEvent|h1|oPbNKOPHBJ|readyState|complete|h3|DOMContentLoaded|right|onreadystatechange|attachEvent|childNodes|try|svg|FILLVECTID1|jpg|||innerWidth|stwWZHHAod|640|160|isNaN|pMgBZuwfYu|marginLeft|zoom|catch|doScroll|border|kcolbdakcolb|styleSheets|script|awesome|moc|keep|doesn|But|without|advertising|income|we|can|making|in|site|YWRuLmViYXkuY29t|understand|have|disabled|my|Let|me|clear|solid|YWQubWFpbC5ydQ|MTM2N19hZC1jbGllbnRJRDI0NjQuanBn|setInterval|insertBefore|468px|undefined|typeof|YWR2ZXJ0aXNlbWVudC0zNDMyMy5qcGc|d2lkZV9za3lzY3JhcGVyLmpwZw|bGFyZ2VfYmFubmVyLmdpZg|YmFubmVyX2FkLmdpZg|ZmF2aWNvbjEuaWNv|c3F1YXJlLWFkLnBuZw|YWQtbGFyZ2UucG5n|Q0ROLTMzNC0xMDktMTM3eC1hZC1iYW5uZXI|YWRjbGllbnQtMDAyMTQ3LWhvc3QxLWJhbm5lci1hZC5qcGc|c2t5c2NyYXBlci5qcGc|anVpY3lhZHMuY29t|YWRzLnlhaG9vLmNvbQ|YWQuZm94bmV0d29ya3MuY29t|YS5saXZlc3BvcnRtZWRpYS5ldQ|YWdvZGEubmV0L2Jhbm5lcnM|YWR2ZXJ0aXNpbmcuYW9sLmNvbQ|Y2FzLmNsaWNrYWJpbGl0eS5jb20||cHJvbW90ZS5wYWlyLmNvbQ|YWRzLnp5bmdhLmNvbQ|NzIweDkwLmpwZw|YWRzYXR0LmFiY25ld3Muc3RhcndhdmUuY29t|YWRzYXR0LmVzcG4uc3RhcndhdmUuY29t|YXMuaW5ib3guY29t|YmFubmVyLmpwZw|okay|NDY4eDYwLmpwZw|Who|b3V0YnJhaW4tcGFpZA|That|QWRGcmFtZTE|YWQtY29udGFpbmVy|YWQtY29udGFpbmVyLTE|YWQtY29udGFpbmVyLTI|QWQzMDB4MTQ1|QWQzMDB4MjUw|QWQ3Mjh4OTA|QWRBcmVh|QWRGcmFtZTI|YWQtbGI|QWRGcmFtZTM|QWRGcmFtZTQ|QWRMYXllcjE|QWRMYXllcjI|QWRzX2dvb2dsZV8wMQ|QWRzX2dvb2dsZV8wMg|QWRzX2dvb2dsZV8wMw|QWRzX2dvb2dsZV8wNA|YWQtZm9vdGVy|YWQtbGFiZWw|RGl2QWQx|127|event|lBSyDaZRrG|frameElement|null|setTimeout|encode|Za|z0|2048|YWQtaW5uZXI|192|c1|191|YWQtbGVmdA|YWRCYW5uZXJXcmFw|YWQtZnJhbWU|YWQtaGVhZGVy|YWQtaW1n|RGl2QWQ|RGl2QWQy|an|Welcome|c3BvbnNvcmVkX2xpbms|262626|adaaad|00a6ff|FFFFFF||Hellow|and|to|YWRzZW5zZQ|Panda|Technology|It|looks|like|you|re|using|Z29vZ2xlX2Fk|cG9wdXBhZA|RGl2QWQz|YWRUZWFzZXI|RGl2QWRB|RGl2QWRC|RGl2QWRD|QWRJbWFnZQ|QWREaXY|QWRCb3gxNjA|QWRDb250YWluZXI|Z2xpbmtzd3JhcHBlcg|YmFubmVyX2Fk|YWRzbG90|YWRCYW5uZXI|YWRiYW5uZXI|YWRBZA|YmFubmVyYWQ|IGFkX2JveA|YWRfY2hhbm5lbA|YWRzZXJ2ZXI|YmFubmVyaWQ|aW5zLmFkc2J5Z29vZ2xl|com|querySelector|UIWrdVPEp7zHy7oWXiUgmR3kdujbZI73kghTaoaEKMOh8up2M8BVceotd|j9xJVBEEbWEXFVZQNX9|1HX6ghkAR9E5crTgM|0t6qjIlZbzSpemi|MjA3XJUKy|SRWhNsmOazvKzQYcE0hV5nDkuQQKfUgm4HmqA2yuPxfMU1m4zLRTMAqLhN6BHCeEXMDo2NsY8MdCeBB6JydMlps3uGxZefy7EO1vyPvhOxL7TPWjVUVvZkNJ|CGf7SAP2V6AjTOUa8IzD3ckqe2ENGulWGfx9VKIBB72JM1lAuLKB3taONCBn3PY0II5cFrLr7cCp|BNyENiFGe5CxgZyIT6KVyGO2s5J5ce|bTplhb|14XO7cR5WV1QBedt3c|QhZLYLN54|e8xr8n5lpXyn|u3T9AbDjXwIMXfxmsarwK9wUBB5Kj8y2dCw|Kq8b7m0RpwasnR|uJylU|dEflqX6gzC4hd1jSgz0ujmPkygDjvNYDsU0ZggjKBqLPrQLfDUQIzxMBtSOucRwLzrdQ2DFO0NDdnsYq0yoJyEB0FHTBHefyxcyUy8jflH7sHszSfgath4hYwcD3M29I5DMzdBNO2IFcC5y6HSduof4G5dQNMWd4cDcjNNeNGmb02|E5HlQS6SHvVSU0V|F2Q|3eUeuATRaNMs0zfml|I1TpO7CnBZO|1FMzZIGQR3HWJ4F1TqWtOaADq0Z9itVZrg1S6JLi7B1MAtUCX1xNB0Y0oL9hpK4|YbUMNVjqGySwrRUGsLu6|uWD20LsNIDdQut4LXA|KmSx||0nga14QJ3GOWqDmOwJgRoSme8OOhAQqiUhPMbUGksCj5Lta4CbeFhX9NN0Tpny|BKpxaqlAOvCqBjzTFAp2NFudJ5paelS5TbwtBlAvNgEdeEGI6O6JUt42NhuvzZvjXTHxwiaBXUIMnAKa5Pq9SL3gn1KAOEkgHVWBIMU14DBF2OH3KOfQpG2oSQpKYAEdK0MGcDg1xbdOWy||||iqKjoRAEDlZ4soLhxSgcy6ghgOy7EeC2PI4DHb7pO7mRwTByv5hGxF|QcWrURHJSLrbBNAxZTHbgSCsHXJkmBxisMvErFVcgE|x0z6tauQYvPxwT0VM1lH9Adt5Lp|h0GsOCs9UwP2xo6|UimAyng9UePurpvM8WmAdsvi6gNwBMhPrPqemoXywZs8qL9JZybhqF6LZBZJNANmYsOSaBTkSqcpnCFEkntYjtREFlATEtgxdDQlffhS3ddDAzfbbHYPUDGJpGT|UADVgvxHBzP9LUufqQDtV|Ly9wYWdlYWQyLmdvb2dsZXN5bmRpY2F0aW9uLmNvbS9wYWdlYWQvanMvYWRzYnlnb29nbGUuanM|szSdAtKtwkRRNnCIiDzNzc0RO|kmLbKmsE|pyQLiBu8WDYgxEZMbeEqIiSM8r|Uv0LfPzlsBELZ|gkJocgFtzfMzwAAAABJRU5ErkJggg|qdWy60K14k|rgba|onmouseover|boxShadow|35px|14px|24px|8px|screen|marginRight|18pt|45px|CCC|999|200|500|hr|borderRadius|12px|background|minWidth|160px|40px|click|split|reverse|join|radius|120|16pt|minHeight|fff|Arial|Black|line|onmouseout|normal|CXRTTQawVogbKeDEs2hs4MtJcNVTY2KgclwH2vYODFTa4FQ|uI70wOsgFWUQCfZC1UI0Ettoh66D|RUIrwGk|rel|Ly93d3cuZ29vZ2xlLmNvbS9hZHNlbnNlL3N0YXJ0L2ltYWdlcy9mYXZpY29uLmljbw|Ly93d3cuZ3N0YXRpYy5jb20vYWR4L2RvdWJsZWNsaWNrLmljbw|blockadblock|http|9999|clearInterval||Ly9hZHZlcnRpc2luZy55YWhvby5jb20vZmF2aWNvbi5pY28|Ly9hZHMudHdpdHRlci5jb20vZmF2aWNvbi5pY28|head|css|stylesheet|link|data|EuJ0GtLUjVftvwEYqmaR66JX9Apap6cCyKhiV|onclick|Ly93d3cuZG91YmxlY2xpY2tieWdvb2dsZS5jb20vZmF2aWNvbi5pY28|Ly95dWkueWFob29hcGlzLmNvbS8zLjE4LjEvYnVpbGQvY3NzcmVzZXQvY3NzcmVzZXQtbWluLmNzcw|reload|setItem|getItem|Date|now|1px|requestAnimationFrame|xlink|innerHeight|png|fn5EREQ9PT3SKSnV1dXks7OsrKypqambmpqRkZFdXV1RUVHRISHQHR309PTq4eHp3NzPz8|cIa9Z8IkGYa9OGXPJDm5RnMX5pim7YtTLB24btUKmKnZeWsWpgHnzIP5UucvNoDrl8GUrVyUBM4xqQ|ejIzabW26SkqgMDA7HByRAADoM7kjAAAAInRSTlM6ACT4xhkPtY5iNiAI9PLv6drSpqGYclpM5bengkQ8NDAnsGiGMwAABetJREFUWMPN2GdTE1EYhmFQ7L339rwngV2IiRJNIGAg1SQkFAHpgnQpKnZBAXvvvXf9mb5nsxuTqDN|b29vlvb2xn5|oGKmW8DAFeDOxfOJM4DcnTYrtT7dhZltTW7OXHB1ClEWkPO0JmgEM1pebs5CcA2UCTS6QyHMaEtyc3LAlWcDjZReyLpKZS9uT02086vu0tJa|base64|v7|aa2thYWHXUFDUPDzUOTno0dHipqbceHjaZ2dCQkLSLy|PzNzc3myMjlurrjsLDhoaHdf3|Lnx0tILMKp3uvxI61iYH33Qq3M24k|v792dnbbdHTZYWHZXl7YWlpZWVnVRkYnJib8|MgzNFaCVyHVIONbx1EDrtCzt6zMEGzFzFwFZJ19jpJy2qx5BcmyBM|Ly8vKysrDw8O4uLjkt7fhnJzgl5d7e3tkZGTYVlZPT08vLi7OCwu|ISwIz5vfQyDF3X|wd4KAnkmbaePspA|0idvgbrDeBhcK|iVBORw0KGgoAAAANSUhEUgAAAKAAAAAoCAMAAABO8gGqAAAB|VOPel7RIdeIBkdo|HY9WAzpZLSSCNQrZbGO1n4V4h9uDP7RTiIIyaFQoirfxCftiht4sK8KeKqPh34D2S7TsROHRiyMrAxrtNms9H5Qaw9ObU1H4Wdv8z0J8obvOo|sAAADMAAAsKysKCgokJCRycnIEBATq6uoUFBTMzMzr6urjqqoSEhIGBgaxsbHcd3dYWFg0NDTmw8PZY2M5OTkfHx|enp7TNTUoJyfm5ualpaV5eXkODg7k5OTaamoqKSnc3NzZ2dmHh4dra2tHR0fVQUFAQEDPExPNBQXo6Ohvb28ICAjp19fS0tLnzc29vb25ubm1tbWWlpaNjY3dfX1oaGhUVFRMTEwaGhoXFxfq5ubh4eHe3t7Hx8fgk5PfjY3eg4OBgYF|sAAADr6|1BMVEXr6'.split('|'),0,{}));
        </script>
</body>

</html>


<?php
//CHECKING FOR THE CAPTCHA AND PERFORMING THE FUNCTIONS DEPENDING ON THE CASES
if (isset($_POST['g-recaptcha-response'])){
    $secret = '6LdSgDAdAAAAAKTZa5kqXtshkxSbsld-C-Bt4V9X';
    $response = $_POST['g-recaptcha-response'];
    $remoteip = $_SERVER['REMOTE_ADDR'];
    $url = 'https://www.google.com/recaptcha/api/siteverify?secret=' . $secret . '&response=' . $response . '&remoteip=' . $remoteip;
    $response = file_get_contents($url);
    $jsResponse = json_decode($response, true);
    if($jsResponse['success'] == 1 ){
        $key = keytodb(generatekey(25));
        echo '<script> document.getElementById("Notif").innerHTML = "Here is your generated key!" </script>';
        echo '<script> document.getElementById("google").style.display = "none";</script>';
        echo '<h3><center>' . $key . '</center></h3>';
    }else{
        echo '<script> document.getElementById("Notif").innerHTML = "Make sure the recaptcha is checked!" </script>';
    }
}



// GENERATING THE RANDOM KEY

function generatekey($length){

 $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

 $charactersLength = strlen($characters);

 $randomString = '';

 for ($i = 0; $i < $length; $i++){

     $randomString .= $characters[rand(0, $charactersLength - 1)];

 }

 return $randomString;

}

// GENERATING THE RANDOM KEY
function keytodb($generatedkey){
    $data = file_get_contents('database.php');
    $data2 = str_replace("<?php", "",$data);
    $data3 = str_replace("?>", "",$data2);
    $data4 =  substr_replace($data3,'\'' . $generatedkey.'\'' . ',',-3,-3);
    file_put_contents('database.php', '<?php' . $data4 . '?>');
    $_SESSION['time'] = NULL;
    $_SESSION['timetwo'] = NULL;
    $_SESSION['timethree'] = NULL;
    return $generatedkey;
}

// SAVING THE KEY INTO THE DATABASE 

?>








