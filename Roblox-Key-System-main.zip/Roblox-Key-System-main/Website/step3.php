<?
ini_set('display_errors', 'Off');
 error_reporting(0);
session_start();

if(time() - $_SESSION['timetwo'] < 10 || !isset($_SESSION['timetwo']))
{
	echo "you did not complete the linkvertise";
	echo "<meta http-equiv='Refresh' Content='4;url=https://pandatechnology.xyz/KeySystem/Panda/step2.php'>"; 
	return;
}
$_SESSION['timethree'] = time();  
?>

<!DOCTYPE html>
<html lang="en">
<head>

  <!-- Basic Page Needs
  ================================================== -->
  <meta charset="utf-8">
  <title>Checkpoint 3 of 3 | Panda Technology(C)</title>
  <script data-cfasync="false" src="//d2fbvay81k4ji3.cloudfront.net/?avbfd=931598"></script>

  <!-- Mobile Specific Metas
  ================================================== -->
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="description" content="Download Panda A+, Top Best Free Roblox Executor, Supports Many Scripts at your finest command.">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
  <meta name="author" content="SkieHacker">
  <meta name="generator" content="Panda-Technology">

  <!-- Favicon -->
  <link rel="shortcut icon" type="https://pandatechnology.xyz/image/x-icon" href="https://pandatechnology.xyz/images/favicon.png" />
  
  <!-- PLUGINS CSS STYLE --> 
  <link rel="stylesheet" href="https://pandatechnology.xyz/plugins/000WebHostGay.css">
  <link rel="stylesheet" href="https://pandatechnology.xyz/plugins/bootstrap/bootstrap.min.css">
  <link rel="stylesheet" href="https://pandatechnology.xyz/plugins/themify-icons/themify-icons.css">
  <link rel="stylesheet" href="https://pandatechnology.xyz/plugins/slick/slick.css">
  <link rel="stylesheet" href="https://pandatechnology.xyz/plugins/slick/slick-theme.css">
  <link rel="stylesheet" href="https://pandatechnology.xyz/plugins/fancybox/jquery.fancybox.min.css">
  <link rel="stylesheet" href="https://pandatechnology.xyz/plugins/aos/aos.css">

  <!-- CUSTOM CSS -->
  <link href="https://pandatechnology.xyz/css/style.css" rel="stylesheet">

</head>

<body class="body-wrapper" data-spy="scroll" data-target=".privacy-nav">


<nav class="navbar main-nav navbar-expand-lg px-2 px-sm-0 py-2 py-lg-0">
  <div class="container">
    <a class="navbar-brand" href="index.html"><img src="https://pandatechnology.xyz/images/logo.png" alt="logo"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
      aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="ti-menu"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">Exploits
            <span><i class="ti-angle-down"></i></span>
          </a>
          <!-- Dropdown list -->
          <ul class="dropdown-menu">
            <li><a class="dropdown-item active" href="index.html">Panda A+</a></li>
            <li><a class="dropdown-item" href="Strelitzia-Exploit.html">Strelitzia-Exploit</a></li>

            <li class="dropdown dropdown-submenu dropright">
              <a class="dropdown-item dropdown-toggle" href="#!" id="dropdown0301" role="button"
                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Other Exploit</a>

              <ul class="dropdown-menu" aria-labelledby="dropdown0301">
                <li><a class="dropdown-item" href="Free_Exploits.html">Free-Exploit</a></li>
                <li><a class="dropdown-item" href="index.html">Tools</a></li>
              </ul>
            </li>
          </ul>
        </li>

		<li class="nav-item @@about">
			<a class="nav-link" href="Scripts.html">Scripts</a>
		</li>

        <li class="nav-item dropdown @@pages">
          <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">Others
            <span><i class="ti-angle-down"></i></span>
          </a>
          <!-- Dropdown list -->
          <ul class="dropdown-menu">
            <li><a class="dropdown-item @@team" href="team.html">Get Key</a></li>
            <li><a class="dropdown-item @@blogSingle" href="blog-single.html">Open-Panda Repository</a></li>
			<li><a class="dropdown-item @@faq" href="FAQ.html">FAQ</a></li>
            <li><a class="dropdown-item @@privacy" href="privacy-policy.html">Privacy</a></li>



          </ul>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="discord.html">Join Discord</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!--================================
=            Page Title            =
=================================-->

<section class="section page-title">
	<div class="container">
		<div class="row">
			<div class="col-sm-8 m-auto">
				<!-- Page Title -->
				<h1>Panda Checkpont 3 ( Last )</h1>
				<!-- Page Description -->
				<p></p>
			</div>
		</div>
	</div>
</section>

<!--====  End of Page Title  ====-->

<style>
    .text-center {
        text-align: center;
    }

    .g-recaptcha {
        display: inline-block;
    }
</style>

<section class="JoinPanda">
  <div>
    <div class="col-12 text-center">
      <p>Please Check If you're Human or Not?</p>
      <p>Checkpoint [ 3 of 3 ]</p>
      <form id="frmContact" action="https://direct-link.net/23330/panda-development-m" method="POST" novalidate="novalidate">
   <div class="g-recaptcha" data-sitekey="6LdSgDAdAAAAALiS5DS8gdU-0WIovu5rNKmTLSHy"></div>
   <div style="text-align: center;">
   <input type="Submit" name="Submit">
      </div>
  </div>
  </form>
</section>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>


<!--============================
=            Footer            =
=============================-->
<footer>
  <div class="text-center footer-main">
    <small class="text-secondary">Copyright &copy; <script>document.write(new Date().getFullYear())</script>. Developed by Panda-Technology</small class="text-secondary">
  </div>
</footer>


  <!-- To Top -->
  <div class="scroll-top-to">
    <i class="ti-angle-up"></i>
  </div>
  
  <!-- JAVASCRIPTS -->
  <script src='https://www.google.com/recaptcha/api.js' async defer ></script>
  <script src="https://pandatechnology.xyz/plugins/jquery/jquery.min.js"></script>
  <script src="https://pandatechnology.xyz/plugins/bootstrap/bootstrap.min.js"></script>
  <script src="https://pandatechnology.xyz/plugins/slick/slick.min.js"></script>
  <script src="https://pandatechnology.xyz/plugins/fancybox/jquery.fancybox.min.js"></script>
  <script src="https://pandatechnology.xyz/plugins/syotimer/jquery.syotimer.min.js"></script>
  <script src="https://pandatechnology.xyz/plugins/aos/aos.js"></script>
  <!-- google map -->
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAgeuuDfRlweIs7D6uo4wdIHVvJ0LonQ6g"></script>
  <script src="https://pandatechnology.xyz/plugins/google-map/gmap.js"></script>
  
  <script src="js/script.js"></script>
</body>

</html>

<?php
  if(!empty($_POST['g-recaptcha-response']))
  {
        $secret = '6LdSgDAdAAAAAKTZa5kqXtshkxSbsld-C-Bt4V9X';
        $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret.'&response='.$_POST['g-recaptcha-response']);
        $responseData = json_decode($verifyResponse);
        if($responseData->success)
            $message = "g-recaptcha varified successfully"; 
        else
            $message = "Some error in vrifying g-recaptcha";
       echo $message;
   }
?>